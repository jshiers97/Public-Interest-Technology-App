$(document).ready(function(){

    $("#search_input").keyup(function(e){
        if (e.keyCode == 13 || e.keyCode == 10){
            $("#submitButton").click();
        }
    })

    $("#submitButton").click(function(){                
        var search = $("#search_input").val()
        query_database(search)
    })
})

var query_database = function(search){
    $.ajax({
        type: "POST",
        url: "search",                
        dataType : "json",
        contentType: "application/json; charset=utf-8",
        data : JSON.stringify(search),

        success: function(result){
            var movie_results = result
            console.log(movie_results)
            view_results(movie_results)
        },
        error: function(request, status, error){
            console.log("Error");
            console.log(request)
            console.log(status)
            console.log(error)
        }
    });
}

var view_results=function(movie_results){
    $("#view_results").empty()

    if (!Array.isArray(movie_results) || !movie_results.length) {
        $("#view_results").html(" No results found")
    }
    else{
        $.each(movie_results, function(i, datum){

            //Search data will show title, year, media, then summary
            var final = $("<div class='row'>")
            var second = $("<div class ='col-md-3'>")
            $(second).append("<div class='search_result' onclick='load_new(" + datum["id"]+ ")'>" +datum["title"] + "</div>")
            $(second).append("</div>")
            final.append(second)
            var third = $("<div class ='col-md-3'>")
            $(third).append(datum["Director"])
            $(third).append("</div>")
            final.append(third)


           

           

            //add it to container, then reset search input and focus the cursor back on the search box
            $("#view_results").prepend(final);
            $('#search_input').val("");
            $("#search_input").focus();
    
        })
    }
}

var load_new=function(id){
    window.location.href = 'http://127.0.0.1:5000/view/' + id;
}

