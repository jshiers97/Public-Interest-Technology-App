$(document).ready(function(){

    $("#search_bar").keyup(function(e){
        if (e.keyCode == 13){
            $("#searchButton").click();
        }
    })

    $("#searchButton").click(function(){                
        var search = $("#search_bar").val()
        console.log(search)
        $("#search_bar").val("")
        search_database(search)
    })  

})
var search_database = function(search){
    $.ajax({
        type: "POST",
        url: "search_database",                
        dataType : "json",
        contentType: "application/json; charset=utf-8",
        data : JSON.stringify(search),

        success: function(result){
            var movie_results = result
            console.log(movie_results)
            console.log("TESTING")
            window.location.href="http://127.0.0.1:5000/search"
        },
        error: function(request, status, error){
            console.log("Error");
            console.log(request)
            console.log(status)
            console.log(error)
        }
    });
}
