/*$(document).ready(function(){

    var link=$("<div onclick='edit_link(" + entry["id"]+ ")'>" + "Link to Edit Entry" + "</div>")
    $("#link_button").append(link)
    console.log(entry["id"])



})
*/

var new_link=function(id){
    window.location.href = 'http://127.0.0.1:5000/view/' + id;
}

var changeTitle=function(){
    var current_title = document.getElementById("title").getAttribute("value")
    $("#title").empty()
    var newTitle=$("<input id='newTitle' class='entryinput'>")
    var submitTitle=$("<button onclick=submit_Title()>Submit</button>")
    var discardTitle = '<button id="discardTitle" onclick="discard_Title(\'' + current_title + '\')">Discard</button>'
    
    $("#title").append(newTitle)
    $("#title").append(submitTitle)
    $("#title").append(discardTitle)

}

var changeYear=function(){
    var current_year = document.getElementById("year").getAttribute("value")
    $("#year").empty()
    
    var newYear=$("<input id='newYear' class='entryinput'>")
    var submitYear=$("<button onclick=submit_Year() >Submit</button>")
    var discardYear = '<button id="discardYear" onclick="discard_Year(\'' + current_year + '\')">Discard</button>'
    $("#year").append(newYear)
    $("#year").append(submitYear)
    $("#year").append(discardYear)

}

var discard_Title=function(current_title){
    $("#title").empty()
    var sameTitle="<div id='title' value='" + current_title + "'>" +  current_title + "</div>"
    $("#title").append(sameTitle)

}

var discard_Year=function(current_year){
    $("#year").empty()
    var sameYear="<div id='title' value='" + current_year + "'>" +  current_year + "</div>"
    $("#year").append(sameYear)

}

var submit_Title=function(){
    var title_field = $("#newTitle").val()
    
    title_id=entry["id"]
    
    updateTitle(title_field, title_id)
}

var submit_Year=function(){
    var year_field = $("#newYear").val()
    year_id=entry["id"]
    updateYear(year_field, year_id)
}

var updateYear=function(year_field, year_id){
    var update={year: year_field, id: year_id}
    $.ajax({
        type: "POST",
        url: "/update_entry_year",                
        dataType : "json",
        contentType: "application/json; charset=utf-8",
        data : JSON.stringify(update),

        success: function(result){
            
            new_link(result["id"])
        },

        error: function(request, status, error){

            $("#link_button").append(Error_text);
            console.log("Error");
            console.log(request)
            console.log(status)
            console.log(error)
        }
    });
}

var updateTitle=function(title_field, title_id){
    var update={title: title_field, id: title_id}
    $.ajax({
        type: "POST",
        url: "/update_entry_title",                
        dataType : "json",
        contentType: "application/json; charset=utf-8",
        data : JSON.stringify(update),

        success: function(result){
            
            new_link(result["id"])
        },

        error: function(request, status, error){
            $("#link_button").append(Error_text);
            console.log("Error");
            console.log(request)
            console.log(status)
            console.log(error)
        }
    });
}

var changeStars=function(){
    $("#stars").empty()
    $.each(entry["Stars"], function(i, datum){
        console.log(datum)
        console.log("here")
        if(datum[1]==false){
            var dataa='<div class="alterText" onclick="chooseDelete(\'' + datum[0] + '\')">' + datum[0] + '</div>'
        }
        else{
            dataa='<div class="alterText" onclick="chooseUndo(\'' + datum[0] + '\')">' + "Undo" + '</div>'
        }
        
        $("#stars").append(dataa)
    })
    
}

var chooseDelete=function(data){
    var update={id: entry["id"], star: data}
    console.log(data)
    console.log("HI")
    console.log(update)
    $.ajax({
        type: "POST",
        url: "/update_entry_cast",                
        dataType : "json",
        contentType: "application/json; charset=utf-8",
        data : JSON.stringify(update),

        success: function(result){
            console.log(result)
            new_link(result["id"])
        },

        error: function(request, status, error){
           
            console.log("Error");
            console.log(request)
            console.log(status)
            console.log(error)
        }
    });
   
}

var chooseUndo=function(data){
    var update={id: entry["id"], star: data}
    console.log(data)
    console.log("HI")
    console.log(update)
    $.ajax({
        type: "POST",
        url: "/update_entry_cast",                
        dataType : "json",
        contentType: "application/json; charset=utf-8",
        data : JSON.stringify(update),

        success: function(result){
            console.log(result)
            new_link(result["id"])
        },

        error: function(request, status, error){
           
            console.log("Error");
            console.log(request)
            console.log(status)
            console.log(error)
        }
    });
   
}



    
