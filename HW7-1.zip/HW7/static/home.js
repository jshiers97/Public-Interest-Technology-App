
var view_more=function(id){
    window.location.href="http://127.0.0.1:5000/view/" + id

}
