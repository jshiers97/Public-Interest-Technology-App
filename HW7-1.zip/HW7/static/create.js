$(document).ready(function(){
    $("#title_input").keyup(function(e){
        if (e.keyCode == 13 || e.keyCode == 10){
            $("#submitButton").click();
        }
    })
    $("#year_input").keyup(function(e){
        if (e.keyCode == 13 || e.keyCode == 10){
            $("#submitButton").click();
        }
    })
    $("#media_input").keyup(function(e){
        if (e.keyCode == 13 || e.keyCode == 10){
            $("#submitButton").click();
        }
    })
    $("#summary_input").keyup(function(e){
        if (e.keyCode == 13 || e.keyCode == 10){
            $("#submitButton").click();
        }
    })
    $("#director_input").keyup(function(e){
        if (e.keyCode == 13 || e.keyCode == 10){
            $("#submitButton").click();
        }
    })
    $("#cast_input").keyup(function(e){
        if (e.keyCode == 13 || e.keyCode == 10){
            $("#submitButton").click();
        }
    })

    
    $("#submitButton").click(function(){                
        var title_field = $("#title_input").val()
        var year_field=  $("#year_input").val()
        var media_field = $("#media_input").val()
        var summary_field = $("#summary_input").val()
        var director_field = $("#director_input").val()
        var cast_field = $("#cast_input").val()

        
       
   
        if(cast_field.trim()==""){
            document.getElementById("require_stars").className ="entryError";
            $('#cast_input').get(0).focus();
        }
        else{
            document.getElementById("require_stars").className="hiddenErrorText";
        }
        if(director_field.trim()==""){
            document.getElementById("require_director").className ="entryError";
            $('#director_input').get(0).focus();
        }
        else{
            document.getElementById("require_director").className="hiddenErrorText";
        }
        if(summary_field.trim()==""){
            document.getElementById("require_summary").className ="entryError";
            $('#summary_input').get(0).focus();
        }
        else{
            document.getElementById("require_summary").className="hiddenErrorText";
        }
        if(media_field.trim()==""){
            document.getElementById("require_media").className ="entryError";
            $('#media_input').get(0).focus();
        }
        else{
            document.getElementById("require_media").className="hiddenErrorText";
        }

        if(year_field.trim()=="" || isNaN(year_field) ){
            document.getElementById("require_year").className ="entryError";
            $('#year_input').get(0).focus();
        }
        else{
            document.getElementById("require_year").className="hiddenErrorText";
        }
        
        if(title_field.trim()==""){
            document.getElementById("require_title").className ="entryError";
            $('#title_input').get(0).focus();
        }
        else{
            document.getElementById("require_title").className="hiddenErrorText";
        }

        if(cast_field.trim()!="" && title_field.trim()!="" && media_field.trim()!="" && summary_field.trim()!="" && director_field.trim()!=""&& year_field.trim()!="" && !isNaN(year_field.trim())){

            $("#title_input").val("")
            $("#year_input").val("")
            $("#media_input").val("")
            $("#summary_input").val("")
            $("#director_input").val("")
            $("#cast_input").val("")
            $("#newSuccess").empty();

            


            var entry={title: title_field, year: year_field, media: media_field, summary: summary_field, Director: director_field, Stars: cast_field}
            add_entry(entry)
        }
    })
})

var add_entry = function(search){
   
    $.ajax({
        type: "POST",
        url: "add_entry",                
        dataType : "json",
        contentType: "application/json; charset=utf-8",
        data : JSON.stringify(search),

        success: function(result){
            console.log("MADE IT")
            console.log(result)
            var new_success=$("<div class='newItem'> New Item Successfully Added </div>")
            $("#newSuccess").append(new_success);
            
            new_link(result)
        },

        error: function(request, status, error){
            var Error_text=$("<div class='entryError'> ENTRY ERROR </div>")
            $("#link_button").append(Error_text);
            console.log("Error");
            console.log(request)
            console.log(status)
            console.log(error)
        }
    });
}

var new_link=function(movie_results){
    $("#link_button").empty(); 
    var new_button=$("<div onclick='load_new(" + movie_results["id"]+ ")'>" + "Link to New Entry" + "</div>")
    $("#link_button").append(new_button);
}

var load_new=function(id){
    window.location.href = 'http://127.0.0.1:5000/view/' + id;
}
