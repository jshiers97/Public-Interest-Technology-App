from flask import Flask
from flask import render_template
from flask import Response, request, jsonify
app = Flask(__name__)

data = [
 {
 "id": 1,
 "title": "The Shining",
 "year" : "1980",
 "media": "https://upload.wikimedia.org/wikipedia/en/thumb/1/1d/The_Shining_%281980%29_U.K._release_poster_-_The_tide_of_terror_that_swept_America_IS_HERE.jpg/220px-The_Shining_%281980%29_U.K._release_poster_-_The_tide_of_terror_that_swept_America_IS_HERE.jpg",
 "alt": "Picture of a breaking through a door with an axe as a terrified woman sits on the other side",
 "summary": """Jack Torrance (Jack Nicholson) becomes winter caretaker at the isolated Overlook Hotel in Colorado, hoping to cure his writers block. He settles in along with his wife, Wendy (Shelley Duvall), and his son, Danny (Danny Lloyd), who is plagued by psychic premonitions. As Jack's writing goes nowhere and Danny's visions become more disturbing, Jack discovers the hotel's dark secrets and begins to unravel into a homicidal maniac hell-bent on terrorizing his family.""",
 "Director": "Stanley Kubrick",
 "Stars": [["Jack Nicholson", False] , ["Shelly Duvall", False] , ["Scatman Crothers", False] , ["Danny Lloyd", False]]
 },
 {
 "id": 2,
 "title": "The Thing",
 "year" : "1982",
 "media": "https://images-na.ssl-images-amazon.com/images/I/91U8fI0EBdL._SY445_.jpg",
 "alt": "Picture of a man in winter clothing with a bright white light shining from his face",
 "summary": """In remote Antarctica, a group of American research scientists are disturbed at their base camp by a helicopter shooting at a sled dog. When they take in the dog, it brutally attacks both human beings and canines in the camp and they discover that the beast can assume the shape of its victims. A resourceful helicopter pilot (Kurt Russell) and the camp doctor (Richard Dysart) lead the camp crew in a desperate, gory battle against the vicious creature before it picks them all off, one by one.""",
 "Director": "John Carpenter",
 "Stars": [["Kurt Russell", False]]
 },
 {
 "id": 3,
 "title": "Aliens",
 "year" : "1982",
 "media": "https://forevercinematic.files.wordpress.com/2012/02/aliens1.jpg",
 "alt": "Picture of a woman holding a small child in one arm and a rifle in the other",
 "summary": """After floating in space for 57 years, Lt. Ripley's (Sigourney Weaver) shuttle is found by a deep space salvage team. Upon arriving at LV-426, the marines find only one survivor, a nine year old girl named Newt (Carrie Henn). But even these battle-hardened marines with all the latest weaponry are no match for the hundreds of aliens that have invaded the colony.""",
 "Director": "James Cameron",
 "Stars": [["Sigourney Weaver", False]]
 },
 {
 "id": 4,
 "title": "A Nightmare on Elm Street",
 "year" : "1984",
 "media": "https://upload.wikimedia.org/wikipedia/en/f/fa/A_Nightmare_on_Elm_Street_%281984%29_theatrical_poster.jpg",
 "alt": "Picture of a girl waking up in bed while metal claws hover above her head",
 "summary": """In Wes Craven's classic slasher film, several Midwestern teenagers fall prey to Freddy Krueger (Robert Englund), a disfigured midnight mangler who preys on the teenagers in their dreams -- which, in turn, kills them in reality. After investigating the phenomenon, Nancy (Heather Langenkamp) begins to suspect that a dark secret kept by her and her friends' parents may be the key to unraveling the mystery, but can Nancy and her boyfriend Glen (Johnny Depp) solve the puzzle before it's too late?""",
 "Director": "Wes Craven",
 "Stars": [["John Saxon", False], ["Ronee Blakley",False],  ["Heather Langenkamp", False] , ["Amanda Wyss", False] , ["Nick Corri", False] , ["Johnny Depp", False] , ["Robert Englund", False]]
 },
 {
 "id": 5,
 "title": "The Fog",
 "year" : "1980",
 "media": "https://resizing.flixster.com/wZty4Nldoq56WGW5Lyfr1wY2_ZA=/206x305/v1.bTsxMTYxNDc2NDtqOzE4NDQ5OzEyMDA7NzY4OzEwMjQ",
 "alt": "Image of dark, ominous figures walking out of a thick fog",
 "summary": """In Wes Craven's classic slasher film, several Midwestern teenagers fall prey to Freddy Krueger (Robert Englund), a disfigured midnight mangler who preys on the teenagers in their dreams - which, in turn, kills them in reality. After investigating the phenomenon, Nancy (Heather Langenkamp) begins to suspect that a dark secret kept by her and her friends' parents may be the key to unraveling the mystery, but can Nancy and her boyfriend Glen (Johnny Depp) solve the puzzle before it's too late?""",
 "Director": "Wes Craven",
 "Stars": [["Adrienne Barbeau", False] , ["Jame Lee Curtis", False], ["John Houseman", False] , ["Janet Leigh", False], ["Tom Atkins", False], ["Nancy Loomis",False]]
 },
{
 "id": 6,
 "title": "Near Dark",
 "year" : "1987",
 "media": "https://resizing.flixster.com/h_F-giulxxq1jhGlGLKwJBxupyU=/206x305/v1.bTsxMTI5MDk5ODtqOzE4NDQ1OzEyMDA7MTIwMDsxNjAw",
 "alt": "Close up of a pale skinned boy with glowing eyes and a girl with creepy figures in the back",
 "summary": """Cowboy Caleb Colton (Adrian Pasdar) meets gorgeous Mae (Jenny Wright) at a bar, and the two have an immediate attraction. But when Mae turns out to be a vampire and bites Caleb on the neck, their relationship gets complicated. Wracked with a craving for human blood, Caleb is forced to leave his family and ride with Mae and her gang of vampires, including the evil Severen. Along the way Caleb must decide between his new love of Mae and the love of his family.""",
 "Director": "Kathryn Bigelow",
 "Stars": [["Adrian Pasdar", False], ["Jenny Wright",False] , ["Lance Henriksen",False], ["Bill Paxton",False], ["Jenette Goldstein",False] , ["Tim Thomerson",False]]
 },
 {
 "id": 7,
 "title": "The Fly",
 "year" : "1986",
 "media": "https://upload.wikimedia.org/wikipedia/en/a/aa/Fly_poster.jpg",
 "alt": "A large insect coming out of a metal shell with a growing green light",
 "summary": """When scientist Seth Brundle (Jeff Goldblum) completes his teleportation device, he decides to test its abilities on himself. Unbeknownst to him, a housefly slips in during the process, leading to a merger of man and insect. Initially, Brundle appears to have undergone a successful teleportation, but the fly's cells begin to take over his body. As he becomes increasingly fly-like, Brundle's girlfriend (Geena Davis) is horrified as the person she once loved deteriorates into a monster.""",
 "Director": "David Cronenberg",
 "Stars": [["Jeff Goldblum",False], ["Geena Davis",False], ["John Getz",False]]
 },
  {
 "id": 8,
 "title": "Gremlins",
 "year" : "1984",
 "media": "https://prodimage.images-bn.com/pimages/0883929646616_p0_v1_s550x406.jpg",
 "alt": "Image of a small, furry animal smiling ",
 "summary": """A gadget salesman is looking for a special gift for his son and finds one at a store in Chinatown. The shopkeeper is reluctant to sell him the 'mogwai' but sells it to him with the warning to never expose him to bright light, water, or to feed him after midnight. All of this happens and the result is a gang of gremlins that decide to tear up the town on Christmas Eve.""",
 "Director": "Joe Dante",
 "Stars": [["Zach Galligan",False], ["Phoebe Cates",False], ["Hoyt Axton",False] , ["Polly Holliday",False] , ["France Lee McCain", False]]
 },
 {
 "id": 9,
 "title": "Poltergeist",
 "year" : "1982",
 "media": "https://vignette.wikia.nocookie.net/horrormovies/images/4/43/Poltergeistposter.jpg/revision/latest?cb=20150304012755",
 "alt": "Image of a little girl putting her hands up to a TV which is showing nothing but static",
 "summary": """Strange and creepy happenings beset an average California family, the Freelings -- Steve (Craig T. Nelson), Diane (JoBeth Williams),teenaged Dana (Dominique Dunne), eight-year-old Robbie (Oliver Robins), and five-year-old Carol Ann (Heather O'Rourke) -- when ghosts commune with them through  the television set. Initially friendly and playful, the spirits turn unexpectedly menacing, and, when Carol Ann goes missing, Steve and Diane turn to a parapsychologist and eventually an exorcist for help.""",
 "Director": "Tobe Hooper",
 "Stars": [["JoBeth Williams", False], ["Craig T. Nelson", False], ["Beatrice Straight", False] ]
 },
 {
 "id": 10,
 "title": "The Evil Dead",
 "year" : "1981",
 "media": "https://images-na.ssl-images-amazon.com/images/I/91LfOWS9rSL._AC_SY741_.jpg",
 "alt": "Various pictures of bloodied human and skeleton faces with a man with a chainsaw in the background",
 "summary": """Ashley 'Ash' Williams (Bruce Campbell), his girlfriend and three pals hike into the woods to a cabin for a fun night away. There they find an old book, the Necronomicon, whose text reawakens the dead when it's read aloud. The friends inadvertently release a flood of evil and must fight for their lives or become one of the evil dead. Ash watches his friends become possessed, and must make a difficult decision before daybreak to save his own life in this, the first of Sam Raimi's trilogy.""",
 "Director": "Sam Raimi",
 "Stars": [["Bruce Campbell", False], ["Ellen Sandweiss", False] , ["Hal Delrich", False] , ["Betsy Baker", False] , ["Theresa Tilly", False] ]
 },
 {
 "id": 11,
 "title": "Maniac",
 "year" : "1980",
 "media": "https://m.media-amazon.com/images/M/MV5BZWI3YjZmY2MtZTVlOS00MDc5LThjYjMtZDMwNmZkZjMzOGI0XkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_.jpg",
 "alt": "Image of a man with a bloodied knife holding a severed head",
 "summary": """A traumatic childhood leads a deranged `mama's boy' on a gruesome killing spree on the streets of New York City.""",
 "Director": "William Lustig",
 "Stars": [["Joe Spinell", False], ["Caroline Munro", False]]
 },
 {
 "id": 12,
 "title": "Friday the 13th",
 "year" : "1980",
 "media": "https://resizing.flixster.com/J2Zr72VXXZrg3dnjfWOPdJVx898=/206x305/v1.bTsxMTE3MjYwNztqOzE4NDQ0OzEyMDA7ODAwOzEyMDA",
 "alt": "The picture of a crystalline lake is shown through the frame of a body holding a knife ",
 "summary": """Crystal Lake's history of murder doesn't deter counselors from setting up a summer camp in the woodsy area. Superstitious
  locals warn against it, but the fresh-faced young people -- Jack (Kevin Bacon), Alice (Adrienne King), Bill (Harry Crosby), Marcie
   (Jeannine Taylor) and Ned (Mark Nelson) -- pay little heed to the old-timers. Then they find themselves stalked by a brutal killer.
  As they're slashed, shot and stabbed, the counselors struggle to stay alive against a merciless opponent.""",
 "Director": "Sean S. Cunningham",
 "Stars": [["Betsy Palmer", False], ["Adrienne King", False], ["Harry Crosby", False], ["Laurie Bartram", False] , ["Mark Nelson", False] , ["Jeannine Taylor", False] , ["Robbi Morgan", False] , ["Kevin Bacon", False]]
 },
  {
 "id": 13,
 "title": "Hellraiser",
 "year" : "1987",
 "media": "https://lh5.googleusercontent.com/proxy/4XvKyiiVYb96TY-35vM9gpbI_IOktSandgeK4-Y9vu7dDjKjm-SY0lvHDv1p6gARj1I1pwPl9oVN7F6OKm2Du1yabXVrIVEZ95nnaQ",
 "alt": "A bald man with pins coming out of his face is shown with chains in the background ",
 "summary": """Sexual deviant Frank (Sean Chapman) inadvertently opens a portal to hell when he tinkers with a box he bought while abroad. The act unleashes gruesome beings called Cenobites, who tear Frank's body apart. When Frank's brother (Andrew Robinson) and his wife, Julia (Clare Higgins), move into Frank's old house, they accidentally bring what is left of Frank back to life. Frank then convinces Julia, his one-time lover, to lure men back to the house so he can use their blood to reconstruct himself.""",
 "Director": "Clive Barker",
 "Stars": [["Andrew Robinson", False], ["Clare Higgins", False], ["Ashley Laurence", False]]
 },
 {
 "id": 14,
 "title": "Prince of Darkness",
 "year" : "1987",
 "media": "https://1.bp.blogspot.com/-M3Oacj2HsJw/VmgtT8nqV0I/AAAAAAABG2Y/cRu9KmUB6jE/s1600/Prince%2Bof%2BDarkness%2B%25281987%2529%2B.jpg",
 "alt": "Many faces are displayed over a church with ominous figures standing in front of it",
 "summary": """Poking around in a church cellar, a priest (Donald Pleasence) finds an otherworldly vial filled with slime. Frightened, he brings his discovery to a circle of top scholars and scientists, who eventually learn that the strange liquid is the essence of Satan. The slime then begins to seep out, turning some of the academics into zombified killers. As the possessed battle the survivors, student Kelly (Susan Blanchard) is infected by a large quantity of the liquid and becomes Satan personified.""",
 "Director": "John Carpenter",
 "Stars": [	["Donald Pleasence", False], ["Lisa Blount", False], ["Victor Wong",False] , ["Dennis Dun", False] , ["Jameson Parker", False]]
 },
  {
 "id": 15,
 "title": "The Stepfather",
 "year" : "1987",
 "media": "https://resizing.flixster.com/SGQ-xjzk8kVh79yIarFXKOemS6U=/206x305/v1.bTsxMTIxMDU0MTtqOzE4NDQ0OzEyMDA7MTUzNjsyMDQ4",
 "alt": "A picture of a man looking at himself in the mirror with the words 'who am I here?' written on it",
 "summary": """Jerry Blake (Terry O'Quinn) is a family man, but he happens to have a series of families, with each one on the receiving end of his murderous ways. When Jerry sets his sights on a lovely widow named Susan (Shelley Hack) and her headstrong daughter, Stephanie (Jill Schoelen), it appears that his brutal pattern of killings will continue. However, Stephanie begins to suspect that there's something wrong with the seemingly well-adjusted Jerry, and a violent confrontation is inevitable.""",
 "Director": "Joseph Ruben",
 "Stars": [	["Terry O'Quinn", False] , ["Jill Schoelen", False] , ["Shelley Hack", False]]
 },
  {
 "id": 16,
 "title": "Creepshow",
 "year" : "1982",
 "media": "https://m.media-amazon.com/images/M/MV5BOTU3NGIyZTctOWEyMS00MGIyLWFkZWMtMTg0ODE2MjExNGZlXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_.jpg",
 "alt": "A skeleton is shown working a ticket booth",
 "summary": """DescriptionA compendium of five short but terrifying tales contained within a single full-length feature, this film conjures scares from traditional bogeymen and portents of doom. In one story, a monster escapes from its holding cell. Another focuses on a husband (Leslie Nielsen) with a creative way of getting back at his cheating wife. Other stories concern a rural man (Stephen King) and a visitor from outer space, and a homeowner (E.G. Marshall) with huge bug problems and a boozing corpse.""",
 "Director": "George A Romero",
 "Stars": [	["Hal Holbrook", False] , ["Adrienne Barbeau", False] , ["Fritz Weaver", False] , ["Leslie Nielsen", False] , ["Carrie Nye", False]]
   }, 
   {
 "id": 17,
 "title": "The Changeling",
 "year" : "1980",
 "media": "https://images-na.ssl-images-amazon.com/images/I/91MbLmqat8L._SX342_.jpg",
 "alt": "An empty, cobwebbed wheelchair is shown despite its shadow showing a small boy sitting in it ",
 "summary": """Composer John Russell (George C. Scott) is vacationing with his family when a car accident kills his wife and daughter. Distraught with grief, Russell leaves his home in New York City for a giant, secluded house near Seattle. Soon Russell starts to feel the presence of a ghost, a boy who drowned in the bathtub there. Russell seeks the assistance of Claire Norman (Trish Van Devere), who led him to the house initially, in uncovering the secrets of the boy's death.""",
 "Director": "Peter Medak",
 "Stars": [	["George C. Scott", False] ,["Trish Van Devere", False] , ["Melvyn Douglas", False] , ["John Colicos", False], ["Jean Marsh", False]]
 },
   {
 "id": 18,
 "title": "The Hitcher",
 "year" : "1986",
 "media": "https://upload.wikimedia.org/wikipedia/en/thumb/9/91/Hitchermovieposter.jpg/220px-Hitchermovieposter.jpg",
 "alt": "An ominous figure blocks the road for a driver",
 "summary": """While transporting a car from Chicago to San Diego, Jim Halsey (C. Thomas Howell) picks up a hitchhiker named John Ryder (Rutger Hauer), who claims to be a serial killer. After a daring escape, Jim hopes to never see Ryder again. But when he witnesses the hitchhiker murdering an entire family, Jim pursues Ryder with the help of truck-stop waitress Nash (Jennifer Jason Leigh), pitting the rivals against each other in a deadly series of car chases and brutal murders.""",
 "Director": "Robert Harmon",
 "Stars": [	["Rutger Hauer", False] ,[ "C. Thomas Howell", False] , ["Jeffrey DeMunn", False] ,[ "Jennifer Jason Leigh", False]]
 },
    {
 "id": 19,
 "title": "Cannibal Holocaust",
 "year" : "1980",
 "media": "https://images.squarespace-cdn.com/content/511eea22e4b06642027a9a99/1400622145867-GJV76C7TH6XP4RI1W5B7/Cannibal+Holocaust.jpg?content-type=image%2Fjpeg",
 "alt": "A woman is shown surrounded by men who look like they're about to eat her",
 "summary": """During a rescue mission into the Amazon rainforest, a professor stumbles across lost film shot by a missing documentary crew whose goal was to study the region's indigenous cannibalistic tribes.""",
 "Director": "Ruggero Deodato",
 "Stars": [	["Robert Kerman", False] , ["Carl Gabriel Yorke", False] , ["Francesca Ciardi", False]]
 },
 {
 "id": 20,
 "title": "The Stuff",
 "year" : "1985",
 "media": "https://resizing.flixster.com/3bJji26iHUf6g9gtelAdkBT2IXs=/206x305/v1.bTsxMzIzNzUwOTtqOzE4Mzc4OzEyMDA7MTUzNjsyMTY3",
 "alt": "A man is shown in agony as a green goo oozes out of his eyes and mouth ",
 "summary": """A private detective investigates a new consumer taste treat that's absolutely delicious and just possibly lethal.""",
 "Director": "Larry Cohen",
 "Stars": [	["Michael Moriarty", False] , ["Andrea Marcovicci", False] ,["Garrett Morris", False] , ["Paul Sorvino", False]]
 },
  {
 "id": 21,
 "title": "The Howling",
 "year" : "1981",
 "media": "https://images-na.ssl-images-amazon.com/images/I/913tiGaMTOL._SL1500_.jpg",
 "alt": "A bloodied werewolf is shown scaring a young couple",
 "summary": """In Los Angeles, television journalist Karen White (Dee Wallace) is traumatized in the course of aiding the police in their arrest of a serial murderer. Her doctor recommends that she attend an isolated psychiatric retreat led by Dr. George Waggner (Patrick Macnee). But while Karen is undergoing therapy, her colleague Chris (Dennis Dugan), investigates the bizarre circumstances surrounding her shock. When his work leads him to suspect the supernatural, he begins to fear for Karen's life.""",
 "Director": "Joe Dante",
 "Stars": [	["Dee Wallace", False], ["Patrick Macnee", False] ,["Dennis Dugan", False]]
 },
  {
 "id": 22,
 "title": "Day of the Dead",
 "year" : "1985",
 "media": "https://images-na.ssl-images-amazon.com/images/I/51EyVI-pqnL._AC_.jpg",
 "alt": "A close up of a zombie's face is shown",
 "summary": """Trapped in a missile silo, a small team of scientists, civilians and trigger-happy soldiers battle desperately to ensure the survival of the human race, but tension inside the base is reaching breaking-point, and the zombies are gathering outside.""",
 "Director": "George A. Romero",
 "Stars": [	["Lori Cardille", False] ,["Terry Alexander", False],["Joe Pilato", False]]
 },
  {
 "id": 23,
 "title": "Fright Night",
 "year" : "1985",
 "media": "https://m.media-amazon.com/images/M/MV5BYTBlOTEzZjYtZTlmMC00OTYyLWIyMTAtNzMzZTRhNzU1YzAyL2ltYWdlXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_UY1200_CR65,0,630,1200_AL_.jpg",
 "alt": "A house in the middle of the nigh is shown with a ghostly figure hovering above",
 "summary": """Teenage Charley Brewster (William Ragsdale) is a horror-film junkie, so it's no surprise that, when a reclusive new neighbor named Jerry Dandridge (Chris Sarandon) moves next-door, Brewster becomes convinced he is a vampire. It's also no surprise when nobody believes him. However, after strange events begin to occur, Charlie has no choice but to turn to the only person who could possibly help: washed-up television vampire killer Peter Vincent (Roddy McDowall).""",
 "Director": "Tom Holland",
 "Stars": [	["Chris Sarandon", False] , ["William Ragsdale", False] , ["Amanda Bearse", False] ]
 },
  {
 "id": 24,
 "title": "Pet Sematary",
 "year" : "1989",
 "media": "https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6328/6328634_sa.jpg",
 "alt": "A cemetery is shown with an angry cat underneath",
 "summary": """DescriptionDr. Louis Creed and his wife, Rachel, relocate from Boston to rural Maine with their two young children. The couple soon discover a mysterious burial ground hidden deep in the woods near their new home. When tragedy strikes, Louis turns to his neighbor Jud Crandall, setting off a perilous chain reaction that unleashes an unspeakable evil with horrific consequences.""",
 "Director": "Mary Lambert",
 "Stars": [	["Dale Midkiff", False] ,[ "Fred Gwynne", False] ,["Denise Crosby", False]]
 },
 {
  "id": 25,
 "title": "Child's Play",
 "year" : "1988",
 "media": "https://cdn.shopify.com/s/files/1/0693/4223/products/Childs_Play_cover_web_740x.jpg?v=1571154004",
 "alt": "A small doll holding a knife is lit up by a flash of lightning",
 "summary": """After moving to a new city, young Andy Barclay receives a special present from his mother -- a seemingly innocent Buddi doll that becomes his best friend. When the doll suddenly takes on a life of its own, Andy unites with other neighborhood  children to stop the sinister toy from wreaking bloody havoc.""",
 "Director": "Tom Holland",
 "Stars": [	["Catherine Hicks", False] , ["Chris Sarandon", False]]
 },
  {
  "id": 26,
 "title": "Bad Taste",
 "year" : "1987",
 "media": "https://upload.wikimedia.org/wikipedia/en/thumb/9/9f/Bad_taste_poster.jpg/215px-Bad_taste_poster.jpg",
 "alt": "A man in a skeleton costume is flipping off the camera with one hand and holding a rifle with the other",
 "summary": """The Astro Investigation and Defence Service (AIDS) sends their agents, Derek, Frank, Ozzy, and Barry to investigate the disappearance of the entire population of the town of Kaihoro. They find the town has been overrun by man-eating space aliens disguised as humans in blue shirts. """,
 "Director": "Peter Jackson ",
 "Stars": [	["Terry Potter", False] ,[ "Pete O'Herne", False] ,["Peter Jackson", False]]
 },
  {
  "id": 27,
 "title": "An American Werewolf in London",
 "year" : "1981",
 "media": "https://s3.amazonaws.com/nightjarprod/content/uploads/sites/4/2018/08/31120608/2afNGBl9nz3mPdiB6Vk78z50l1o.jpg",
 "alt": "A man's tranformation into a werewolf is shown ",
 "summary": """David (David Naughton) and Jack (Griffin Dunne), two American college students, are backpacking through Britain when a large wolf attacks them. David survives with a bite, but Jack is brutally killed. As David heals in the hospital, he's plagued by violent nightmares of his mutilated friend, who warns David that he is becoming a werewolf. When David discovers the horrible truth, he contemplates committing suicide before the next full moon causes him to transform from man to murderous beast.""",
 "Director": "John Landis",
 "Stars": [	["David Naughton", False] ,["Jenny Agutter", False] , ["Griffin Dunne", False],["John Woodvine", False]]
 },
   {
  "id": 28,
 "title": "Childen of the Corn",
 "year" : "1984",
 "media": "https://images-na.ssl-images-amazon.com/images/I/81eyn6HK%2BvL._SX342_.jpg",
 "alt": "A small child with creepy eyes is shown in a corn field",
 "summary": """As physician Burt Stanton (Peter Horton) and his girlfriend, Vicky (Linda Hamilton), drive across the Midwest to his new job, their trip comes to a sudden halt when they encounter the body of a murdered boy in the road. In trying to contact the authorities, Burt and Vicky wander into a small town populated only by children, followers of sinister young preacher Isaac Chroner (John Franklin). Soon the couple is fleeing the youthful fanatics, who want to sacrifice them to their demonic deity.""",
 "Director": "Fritz Kiersch",
 "Stars": [	["Peter Horton", False] , ["Linda Hamilton", False]]
 },
    {
  "id": 29,
 "title": "My Bloody Valentine",
 "year" : "1981",
 "media": "https://screamfestla.com/sites/default/files/styles/portfolio_view/public/image-events/mbv1200x700.jpg?itok=u1wYR02w",
 "alt": "A miner holding an axe is shown choking a woman",
 "summary": """Friends defy the rules of a legendary murderer and discover he is real when they start celebrating Valentine's Day. """,
 "Director": "George Mihalka",
 "Stars": [	["Paul Kelman", False] ,["Lori Hallier", False],["Neil Affleck", False],["Don Francks", False] , ["Cynthia Dale", False], ["Alf Humphreys", False] , ["Keith Knight", False], ["Patricia Hamilton", False]]
 },
  {
  "id": 30,
 "title": "Motel Hell",
 "year" : "1980",
 "media": "https://static.tvtropes.org/pmwiki/pub/images/mh.PNG",
 "alt": "A country couple holding bloodied tools and a severed foot is shown",
 "summary": """Vincent Smith (Rory Calhoun) and his sister Ida (Nancy Parsons) run a rural hotel, but they earn most of their cash operating a food stand that specializes in world-famous sausages. After years of success, however, the duo's upstanding brother, Sheriff Bruce (Paul Linke), eventually discovers the grotesque details of his siblings' booming business: Vincent and Ida are actually plumping up their hotel patrons, killing and dismembering them and then grinding them into frankfurters.""",
 "Director": "George Mihalka",
 "Stars": [	["Paul Kelman", False] , ["Lori Hallier", False] , ["Neil Affleck", False]]
 },
]

current_id=30

search_results=[]

search_size=0

@app.route('/')
def people():
    last_ten=[]
    for i in range(10):
            last_ten.append(data[(current_id-i)-1])

    return render_template('home.html', last_ten=last_ten)  

@app.route('/create')
def create_entry():
    return render_template('create.html', data=data)

@app.route("/view/<id>")
def display_entry(id=None):
    id_int=int(id)
    for entry in data:
        if id_int==entry["id"]:
            return render_template('view.html', entry=entry)
    



@app.route('/search_database', methods=['GET', 'POST'])
def search():
    global data
    global search_results
    global search_size
    
    search_results=[]

    json_data = request.get_json() 
    
    for entry in data:
        if json_data.lower() in entry["title"].lower():
            search_results.append(entry)
        if json_data.lower() in entry["Director"].lower():
            search_results.append(entry)

    
    search_size=len(search_results)
    if not search_results:
        return jsonify("No results found")
    else:
        return jsonify(search_results)


@app.route("/search")
def display_results():
    return render_template('search.html', search_results=search_results, search_size=search_size)
            
            
#@app.route('/delete_entry', methods=['GET', 'POST'])
#def delete_entry(id=None):
    #global data
   # json_data = request.get_json()
    
    #for entry in data:
       # if entry["id"] == json_data:
       #     data.remove(entry) 
          #  movie_name=entry["title"]


    # send back the sales, no need to send back clients because autocomplete
    # never deletes entries 
    #return jsonify(movie_name)

@app.route('/add_entry', methods=['GET', 'POST'])
def add_entry():
    global data
    global current_id
    current_id+=1
    json_data=request.get_json()
    title=json_data["title"]
    year=json_data["year"]
    summary=json_data["summary"]
    media=json_data["media"]
    director=json_data["Director"]
    star_raw=json_data["Stars"]
    stars=[[star_raw, False]]

    
    entry={"id": current_id, "title": title, "year": year, "summary": summary, "media": media, "Director": director, "Stars":stars }
    

    
    data.append(entry)
    return jsonify(entry)



@app.route('/update_entry_title', methods=['GET', 'POST'])
def update_entry_title():
    global data

    update=request.get_json()
    id_int=int(update["id"])
    title_update=update["title"]
    for entry in data:
        if id_int==entry["id"]:
            entry["title"]=title_update
            return jsonify(entry)
    

@app.route('/update_entry_year', methods=['GET', 'POST'])
def update_entry_year():
    global data

    update=request.get_json()
    id_int=int(update["id"])
    year_update=update["year"]
    for entry in data:
        if id_int==entry["id"]:
            entry["year"]=year_update
            return jsonify(entry)

@app.route('/update_entry_cast', methods=['GET', 'POST'])
def update_entry_cast():
    global data

    update=request.get_json()
    id_int=int(update["id"])
    cast_update=update["star"]
    for entry in data:
        if id_int==entry["id"]:
            for star in entry["Stars"]:
                if star[0]==cast_update:
                    if star[1]==True:
                        star[1]=False
                    else:
                        star[1]=True
                    return jsonify(entry)

    



if __name__ == '__main__':
   app.run(debug = True)